"""empty message

Revision ID: 130ec662e98e
Revises: 30dc7f6b846a
Create Date: 2020-01-26 01:24:46.869388

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '130ec662e98e'
down_revision = '30dc7f6b846a'
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
