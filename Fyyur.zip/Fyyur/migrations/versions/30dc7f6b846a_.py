"""empty message

Revision ID: 30dc7f6b846a
Revises: 
Create Date: 2020-01-26 01:24:04.574890

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '30dc7f6b846a'
down_revision = None
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
